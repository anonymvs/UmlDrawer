//
// Created by hegedus on 2017.12.14..
//

#ifndef UMLDRAWER_VISIBILITY_H
#define UMLDRAWER_VISIBILITY_H

enum Visibility {
    PUBLIC,
    PRIVATE,
    PROTECTED
};

#endif //UMLDRAWER_VISIBILITY_H
